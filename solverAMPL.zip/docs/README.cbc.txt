cbcmp tutorial driver
=======================

Work in progress. Alpha version of mp-based driver for cbc.